# Confluence Flow

Confluence 文档工作台：标准 wiki 读写、正文与右侧目录、页面版本检查，以及 DSH / CLI / MCP / Skills 共用的运行层。

## 首版能力

- 搜索、按页面 ID 或 URL 读取、子页面和附件列表；分页返回 nextStart。
- 标准 Confluence wiki 转 storage，原生 two_right_sidebar + toc 布局。
- 指定父页新建、追加正文、替换章节、整页更新；预览、版本冲突检查和提交回执。
- DSH 全页与工作区分栏，页面加入当前会话草稿，保留已有输入。
- confluence_flow 原生工具和 stdio MCP；confluence-query / confluence-publish / confluence-update Skills。

读取会保留原始 storage 底稿。wiki 是阅读/编写表示，任意旧页面不保证无损反向转换。部分修改保留范围外的原始字符。复杂宏在本地预览显示占位或内容摘要；最终动态效果请打开 Confluence 原网页。第一版提供附件列表，不上传附件；本地预览以文本标注图片引用。

局部章节编辑以 read 返回的 sections 为准；复杂宏或复杂容器内部的标题不会自动作为替换边界。

## 安装与运行

Node.js 20.19+。Windows 安装、构建和测试使用 scripts/run-bounded.ps1，它以 Job Object 管理进程树和超时。

```powershell
./scripts/run-bounded.ps1 -Executable node -CommandArgs @('C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js','install','--no-audit','--no-fund') -TimeoutSeconds 180
./scripts/run-bounded.ps1 -Executable node -CommandArgs @('scripts/build.mjs') -TimeoutSeconds 90
& "$env:LOCALAPPDATA/Programs/DeepSeek Harness/resources/runtime/cli/bin/dsh.cmd" plugin --profile desktop add link:D:/dev/vscode/confluence-flow
```

使用 DSH 桌面端随附的 CLI 安装 desktop profile；系统 PATH 中另一版本的 dsh 可能不能管理 desktop。DSH 正常重启或宿主支持的插件重载后，打开“Confluence 文档”。安装是本地链接，移动项目后需要重新安装链接。

```powershell
node D:/dev/vscode/confluence-flow/dist/cli.js auth import-obsidian --source D:/vault/.obsidian/plugins/confluence-sync/data.json
node D:/dev/vscode/confluence-flow/dist/cli.js auth writes --enabled true
node D:/dev/vscode/confluence-flow/dist/cli.js doctor
node D:/dev/vscode/confluence-flow/dist/cli.js skills install
```

Skills 安装到 ~/.agents/skills、~/.codex/skills 和 ~/.claude/skills；已有同名目录保留，不自动覆盖。`--output` 可指定其他路径。DSH 插件同时注册随包的 Skills。每个 Skill 的 scripts/run.mjs 通过 ~/.confluence-flow/installation.json 定位 CLI；不依赖 DSH 保持运行。

## Agent 使用

DSH agent 直接调用 `confluence_flow`。Codex / Claude Code 可通过安装的 Skills 调用 CLI，也可以配置 MCP：

```json
{
  "mcpServers": {
    "confluence-flow": {
      "command": "node",
      "args": ["D:/dev/vscode/confluence-flow/dist/cli.js", "mcp"]
    }
  }
}
```

这是通用 JSON MCP 配置；客户端配置格式可能不同，Codex TOML 示例：

```toml
[mcp_servers.confluence-flow]
command = "node"
args = ["D:/dev/vscode/confluence-flow/dist/cli.js", "mcp"]
```

配置中无需账号、密码或 token。MCP 使用与 DSH 相同的工具名和参数。可用操作：profiles、doctor、search、read、children、attachments、preview、create、update、commit、operation-status。`node dist/cli.js --help` 查看 CLI 参数。

本机交付已通过客户端命令注册，无需重复手动配置。其他机器可使用 `codex mcp add confluence-flow -- node <CLI绝对路径> mcp`，或 `claude mcp add --transport stdio --scope user confluence-flow -- node <CLI绝对路径> mcp`。官方接入说明：[Codex MCP](https://developers.openai.com/codex/mcp)、[Claude Code MCP](https://code.claude.com/docs/en/mcp)。

```powershell
node dist/cli.js search --query 接口 --parent 12345
node dist/cli.js read --page 12345
node dist/cli.js call --input request.json --wiki-file document.wiki
node dist/cli.js commit --draft-id DRAFT_ID --request-id UNIQUE_REQUEST_ID
```

创建请求示例：

```json
{"operation":"create","parent":"12345","title":"接口说明","layout":"right-toc"}
```

正文通过 --wiki-file 读取；也可以在 JSON 中提供 wiki 字符串。create/update 默认生成预览草稿；明确授权后使用 commit，或 apply=true + requestId。局部更新需 expectedVersion，replace-section 需 read 返回的 sectionId。章节替换保留标题并包含子章节。单个正文区域可自动选择，多区域 append 需 regionId。整篇替换可选择 right-toc 或 plain。

页面版本冲突需要重新读取。提交超时、pending 或 unknown 状态需要核实原页面，不自动重发。相同请求标识不能用于不同内容。预览不修改 Confluence 页面。

## 用户数据

默认 ~/.confluence-flow，可通过 CONFLUENCE_FLOW_HOME 指定。profiles 保存非秘密连接；credentials 保存 Windows DPAPI CurrentUser 密文；snapshots 保存读取底稿；drafts 保存待发布内容；operations 保存提交回执；installation.json 记录运行层位置。快照与草稿是恢复用用户资料，不属于仓库或自动删除的测试文件。

Windows 凭据通过子进程标准输入保护，不放入参数或工具结果。它依赖当前 Windows 用户，不能抵御同一用户下任意代码访问。其他系统使用 credentialStore=environment，变量名为 CONFLUENCE_FLOW_AUTH_<大写连接别名，非字母数字替换为下划线>，值为 basic 或 bearer 认证 JSON；不要在聊天、仓库或配置示例中写真实值。

连接设置支持常用发布位置别名。浏览根页面只影响默认检索，真实写入目标由父页或页面参数确定，并受 Confluence 自身权限约束。

## 独立界面与验证

`node dist/cli.js serve` 在 http://127.0.0.1:43138 提供相同文档面板，Ctrl+C 结束。该入口供用户主动使用，自动化验证启动的服务必须在验证后清理。

实施计划见 docs/implementation-plan.md，验证记录见 docs/verification.md。部分基础设施改编自 MIT 许可的 Jira Flow，许可保留在 LICENSE。
